1. Get Query results - Super
Usage: getQueryResultByOrg.py appServer user password, inputXML
Example: python getQueryResultByOrg.py 192.168.20.116 super/admin adm1n top_fortisiem_events_by_count.xml

2. Get Query results - Org (2001)
Usage: getQueryResultByOrg.py appServer user password, inputXML
Example: python getQueryResultByOrg.py 192.168.20.116 super/admin adm1n top_fortisiem_events_by_count_org.xml
